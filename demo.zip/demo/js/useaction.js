
var stageWidth,stageHeight,distance,container;
var scene,camera,renderer,controls;
var groupSP;
var materialA;
var materialB;
var sphereMesh,sphereLightsMesh,sphereCloudsMesh;
var starMax;
var starMin;
var ua = navigator.userAgent;
var ipad = ua.match(/(iPad).*OS\s([\d_]+)/),
isIphone =!ipad && ua.match(/(iPhone\sOS)\s([\d_]+)/),
isAndroid = ua.match(/(Android)\s+([\d.]+)/),
isMobile = isIphone || isAndroid;
if(isMobile){
    starMax = 5;
    starMin = 3;
}else{
    starMax = 3;
    starMin = 1;
}

function show(sWidth,sHeight,distanceSize,con,isShow){
    stageWidth=sWidth;
    stageHeight=sHeight;
    distance=distanceSize;
    container=con;
    init();
    animate(isShow);
    document.getElementsByTagName("canvas")[0].style.display="block";
}

function init(){
    scene = new THREE.Scene();
//			scene.background = new THREE.Color( 0x0a0a0a );
    //scene.fog = new THREE.Fog( 0xffffff, 100, 10000 );

    camera = new THREE.PerspectiveCamera( distance, (stageWidth / stageHeight), 1, 100000 );
    camera.position.z = 400;

    renderer = new THREE.WebGLRenderer({antialias:true,alpha:true});
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ReinhardToneMapping;
    renderer.toneMappingExposure = 0.5;
    renderer.physicallyCorrectLights =true;

    renderer.setSize( stageWidth,stageHeight);
    //背景透明
    renderer.setClearAlpha(0);

    container.appendChild( renderer.domElement );

    controls = new THREE.OrbitControls( camera, renderer.domElement );

    controls.minDistance = 150;
    controls.maxDistance = 500;
    controls.enableDamping = true; 
    controls.dampingFactor = 0.05;
    /**
    * 控制器操作用这个
    */
    controls.mouseButtons = {
        LEFT: THREE.MOUSE.ROTATE,
        MIDDLE: THREE.MOUSE.DOLLY
    }
    controls.touches = {
        ONE: THREE.TOUCH.ROTATE,
        TWO: THREE.TOUCH.DOLLY_ROTATE
    }

    //漫射
    var earthMat = new THREE.MeshPhongMaterial( {color: 0xffffff,shininess: 0	} );
    var textureLoader = new THREE.TextureLoader();
        textureLoader.load( 'mytextures/earth_atmos_2048.jpg', function ( tex ) {
        earthMat.map = tex;
        earthMat.map.encoding = THREE.sRGBEncoding;
        earthMat.needsUpdate = true;
        earthMat.normalScale = new THREE.Vector2( 2, -2 );
    } );
    //镜面
    textureLoader.load( 'mytextures/earth_specular_2048.jpg', function ( tex ) {
        earthMat.specularMap = tex;
        earthMat.specularMap.encoding = THREE.sRGBEncoding;
        earthMat.needsUpdate = true;
    } );
    //法线
    var earthNormal = textureLoader.load( 'mytextures/earth_normal_2048.jpg', function( tex ) {
    earthMat.normalMap = tex;
    earthMat.needsUpdate = true;

    } );
    //夜晚灯光材质
    var earthLights = textureLoader.load( 'mytextures/earth_lights_2048.png' );
    earthLights.encoding = THREE.sRGBEncoding;

    var earthLightsMat = new THREE.MeshBasicMaterial( {
        color: 0xffffff,
        blending: THREE.AdditiveBlending,
        transparent: true,
        depthTest: false,
        map: earthLights,
    } );

    var clouds = textureLoader.load( 'mytextures/earth_clouds_1024.png' );
    clouds.encoding = THREE.sRGBEncoding;

    var earthCloudsMat = new THREE.MeshLambertMaterial( {
        color: 0xffffff,
        blending: THREE.NormalBlending,
        transparent: true,
        depthTest: false,
        map: clouds
    } );

    /******************************光源******************************/
    var ambient = new THREE.AmbientLight( 0x050505 );
    scene.add( ambient );

    var directionalLight = new THREE.DirectionalLight( 0xffffff,4);
    directionalLight.position.set( 2, 0, 10 ).normalize();
    scene.add( directionalLight );

    /******************************大气shader******************************/
    var atmoShader = {
        side: THREE.BackSide,

        transparent: true,
        lights: true,
        uniforms: THREE.UniformsUtils.merge( [
            THREE.UniformsLib[ "common" ],
            THREE.UniformsLib[ "lights" ]
        ] ),
        vertexShader: [
            "varying vec3 vViewPosition;",
            "varying vec3 vNormal;",
            "void main() {",
            THREE.ShaderChunk[ "beginnormal_vertex" ],
            THREE.ShaderChunk[ "defaultnormal_vertex" ],
            "	vNormal = normalize( transformedNormal );",
            "vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );",
            "vViewPosition = -mvPosition.xyz;",
            "gl_Position = projectionMatrix * mvPosition;",
            "}"
        ].join( "\n" ),
        fragmentShader: [
            THREE.ShaderChunk[ "common" ],
            THREE.ShaderChunk[ "bsdfs" ],
            THREE.ShaderChunk[ "lights_pars_begin" ],
            THREE.ShaderChunk[ "lights_phong_pars_fragment" ],
            "void main() {",
            "vec3 normal = normalize( -vNormal );",
            "vec3 viewPosition = normalize( vViewPosition );",
            "#if NUM_DIR_LIGHTS > 0",
            "vec3 dirDiffuse = vec3( 0.0 );",
            "for( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {",
            "vec4 lDirection = viewMatrix * vec4( directionalLights[i].direction, 0.0 );",
            "vec3 dirVector = normalize( lDirection.xyz );",
            "float dotProduct = dot( viewPosition, dirVector );",
            "dotProduct = 1.0 * max( dotProduct, 0.0 ) + (1.0 - max( -dot( normal, dirVector ), 0.0 ));",
            "dotProduct *= dotProduct;",
            "dirDiffuse += max( 0.5 * dotProduct, 0.0 ) * directionalLights[i].color;",
            "}",
            "#endif",

            "float viewDot = abs(dot( normal, viewPosition ));",
            "viewDot = clamp( pow( viewDot + 0.6, 10.0 ), 0.0, 1.0);",
            "vec3 color = vec3( 0.05, 0.09, 0.13 ) * dirDiffuse;",
            "gl_FragColor = vec4( color, viewDot );",
            "}"
        ].join( "\n" )
    };
    /********************************************************************/
    var earthAtmoMat = new THREE.ShaderMaterial( atmoShader );

    var earthGeo = new THREE.SphereBufferGeometry( 30, 50, 50 );
    sphereMesh = new THREE.Mesh( earthGeo, earthMat);
    scene.add( sphereMesh );

    sphereLightsMesh = new THREE.Mesh( earthGeo, earthLightsMat );
    scene.add( sphereLightsMesh );

    sphereCloudsMesh = new THREE.Mesh( earthGeo, earthCloudsMat );
    scene.add( sphereCloudsMesh );

    var sphereAtmoMesh = new THREE.Mesh( earthGeo, earthAtmoMat );
    sphereAtmoMesh.scale.set( 1.1, 1.1, 1.1 );
    scene.add( sphereAtmoMesh );

    /*******************************星星*************************************/
//			var i, r = 500, starsGeometry = [ new THREE.BufferGeometry(), new THREE.BufferGeometry() ];
//			var vertices1 = [];
//			var vertices2 = [];
//			var vertex = new THREE.Vector3();
//			for ( i = 0; i < 250; i ++ ) {
//				vertex.x = Math.random() * 2 - 1;
//				vertex.y = Math.random() * 2 - 1;
//				vertex.z = Math.random() * 2 - 1;
//				vertex.multiplyScalar( r );
//				vertices1.push( vertex.x, vertex.y, vertex.z );
//			}
//			for ( i = 0; i < 1500; i ++ ) {
//				vertex.x = Math.random() * 2 - 1;
//				vertex.y = Math.random() * 2 - 1;
//				vertex.z = Math.random() * 2 - 1;
//				vertex.multiplyScalar( r );
//				vertices2.push( vertex.x, vertex.y, vertex.z );
//			}
//			starsGeometry[ 0 ].setAttribute( 'position', new THREE.Float32BufferAttribute( vertices1, 3 ) );
//			starsGeometry[ 1 ].setAttribute( 'position', new THREE.Float32BufferAttribute( vertices2, 3 ) );
//			var stars;
//			var starsMaterials = [
//				new THREE.PointsMaterial( { color: 0x555555, size: starMax, sizeAttenuation: false } ),
//				new THREE.PointsMaterial( { color: 0x555555, size: starMin, sizeAttenuation: false } ),
//				new THREE.PointsMaterial( { color: 0x333333, size: starMax, sizeAttenuation: false } ),
//				new THREE.PointsMaterial( { color: 0x3a3a3a, size: starMin, sizeAttenuation: false } ),
//				new THREE.PointsMaterial( { color: 0x1a1a1a, size: starMax, sizeAttenuation: false } ),
//				new THREE.PointsMaterial( { color: 0x1a1a1a, size: starMin, sizeAttenuation: false } )
//			];
//			for ( i = 10; i < 30; i ++ ) {
//				stars = new THREE.Points( starsGeometry[ i % 2 ], starsMaterials[ i % 6 ] );
//				stars.rotation.x = Math.random() * 6;
//				stars.rotation.y = Math.random() * 6;
//				stars.rotation.z = Math.random() * 6;
//				stars.scale.setScalar( i * 10 );
//				stars.matrixAutoUpdate = false;
//				stars.updateMatrix();
//				scene.add( stars );
//			}

			
			/*********************************sprite**************************************/
			 var spriteA = textureLoader.load( "mytextures/sprite0.png" );
			var spriteB = textureLoader.load( "mytextures/sprite1.png" );
			
			materialA = new THREE.SpriteMaterial( { map: spriteA, color: 0xffffff, fog: true } );
			materialB = new THREE.SpriteMaterial( { map: spriteB, color: 0xffffff, fog: true } );
			//sprite组群
			groupSP = new THREE.Group();
			//创建sprite
			for ( var a = 0; a < 9; a ++ ) {
				var material = materialA.clone();
				var sprite = new THREE.Sprite( material );
				sprite.position.normalize();
				//为每个line创建group，用于后面独立调整line的角度
				var group = new THREE.Group();
				group.scale.multiplyScalar( 10 );
				group.add(sprite);
				//将子group 添加到组群中
				groupSP.add( group );
			}
			scene.add( groupSP );
			
			/*********************************卫星轨道**************************************/
			//设置line的段数
			var vertices = [];
			var divisions = 50;
			for ( var i = 0; i <= divisions; i ++ ) {
				var v = ( i / divisions ) * ( Math.PI * 2 );
				var x = Math.sin( v );
				var z = Math.cos( v );
				vertices.push( x, 0, z );
			}
			
			//设定line的定点着色器
			var geometry = new THREE.BufferGeometry();
			geometry.setAttribute( 'position', new THREE.Float32BufferAttribute( vertices, 3 ) );
			
			//实例化line
			for ( var i = 1; i <= 9; i ++ ) {
				var material = new THREE.LineDashedMaterial( {color: 0x2555e0,linewidth: 3,dashSize: 0.01, gapSize: 0.01} );
				var line = new THREE.Line( geometry, material );
				line.computeLineDistances();
				line.scale.setScalar( 80 );
				//设定每个line的角度
				line.rotation.x = i/7 * Math.PI;
				line.rotation.y = i*9 * Math.PI;
				line.rotation.z = i/9 * Math.PI;
				scene.add( line );
				
				//读取组群中的每一个sprite 
				var group = groupSP.children[i - 1];
				//设定子group 中sprite的坐标 与每条line 一一对应
				group.children[0].position.set( line.geometry.attributes.position.array[i * 15],
												line.geometry.attributes.position.array[i * 15 + 1], 
												line.geometry.attributes.position.array[i * 15 + 2] 
											);
				//设定每个子group的角度 与每一条line 一一对应
				group.rotation.x = i/7 * Math.PI;
				group.rotation.y = i*9 * Math.PI;
				group.rotation.z = i/9 * Math.PI;
				//调整坐标比例
				group.children[0].position.multiplyScalar( 8 );
			}

			/***************************************************************************/
			window.addEventListener( 'resize', onWindowResize, false );
			//window.addEventListener( "click", onDocumentMouseClick, false );
			}
			
			
    var selectedObject = null;
function onDocumentMouseClick( event ) {
    event.preventDefault();

    if ( selectedObject ) {
        selectedObject.material.map = materialA.map;
        selectedObject = null;
    }
    var intersects = getIntersects( event.layerX, event.layerY );
    if ( intersects.length > 0 ) {
        var res = intersects.filter( function ( res ) {
            return res && res.object;
        } )[ 0 ];
        if ( res && res.object ) {
            selectedObject = res.object;
            selectedObject.material.map = materialB.map;
        }
    }

}
var raycaster = new THREE.Raycaster();
var mouseVector = new THREE.Vector3();

function getIntersects( x, y ) {

    x = ( x / window.innerWidth ) * 2 - 1;
    y = - ( y / window.innerHeight ) * 2 + 1;

    mouseVector.set( x, y, 0.5 );
    raycaster.setFromCamera( mouseVector, camera );

    return raycaster.intersectObject( groupSP, true );

}
				
			
function onWindowResize() {

    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize( window.innerWidth, window.innerHeight );
    //console.log(window.innerWidth);
}


/********************************************************/
function animate(a) {
    requestAnimationFrame( animate );
    renderer.render( scene, camera );
    controls.update();

    sphereMesh.rotation.y = sphereLightsMesh.rotation.y += 0.0001;
    sphereCloudsMesh.rotation.y += 0.0002;

        var canvass = document.getElementsByTagName("canvas")[0];
        canvass.getContext('2d')
        var img = document.getElementById("img");
        img.setAttribute("src",canvass.toDataURL("image/png"))


}